/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, Task, TaskPriority, TaskStatus, Department } from '../types';
import { DB } from '../lib/dataStore';
import { 
  FileSpreadsheet, 
  Upload, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  HelpCircle, 
  Copy, 
  ArrowRight,
  Database,
  Grid3X3
} from 'lucide-react';

interface AIImportProps {
  currentUser: User;
  onImportComplete: (importedTasks: Task[]) => void;
}

export default function AIImport({ currentUser, onImportComplete }: AIImportProps) {
  const [pasteContent, setPasteContent] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadFeedback, setUploadFeedback] = useState('');
  const [parsedResult, setParsedResult] = useState<{ confidenceScore: number; tasks: any[] } | null>(null);

  // Download template mockup trigger
  const [showTemplateTip, setShowTemplateTip] = useState(false);

  // Template spreadsheet content for easy copying
  const sampleTemplateText = `Dự án\tTháng Kế Hoạch\tTuần\tTên Công Việc\tNội dung chi tiết\tNgười chịu trách nhiệm\tPhòng ban\tƯu tiên\tHạn chót\tĐiểm KPI
Marketing VF5\tTháng 6\tTuần 1\tThiết kế banner in ấn\tLên maket decal dán cuộn\tNguyễn Văn Nam\tMarketing\tHigh\t23-10-2026\t15
Xưởng Tem Vivian\tTháng 6\tTuần 2\tBảo trì đầu phun dầu UV\tLau sạch đầu sấy và mực cũ\tTrần Minh Đức\tKỹ thuật\tHigh\t20-10-2026\t20
Hợp đồng Sales Thép\tTháng 6\tTuần 2\tTư vấn khách sỉ Hải Phòng\tKý hợp đồng in tem chống giả\tLê Thị Thuỷ\tSale\tMedium\t25-10-2026\t10`;

  const copyTemplate = () => {
    navigator.clipboard.writeText(sampleTemplateText);
    setUploadFeedback('Đã copy bảng mẫu Excel vào Clipboard! Hãy dán (Ctrl+V) vào ô nhập dữ liệu bên dưới.');
    setTimeout(() => setUploadFeedback(''), 4000);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setPasteContent(text);
        setUploadFeedback(`Đã đọc nội dung file: ${file.name} thành công!`);
      };
      reader.readAsText(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setPasteContent(text);
        setUploadFeedback(`Đã đọc nội dung file: ${file.name} thành công. Hãy bấm "Dùng AI Phân Tích Cột" bên dưới.`);
      };
      reader.readAsText(file);
    }
  };

  const executeAiAnalysis = async () => {
    if (!pasteContent.trim()) {
      setUploadFeedback('Vui lòng nhập hoặc dán bảng cells dữ liệu trước khi phân tích!');
      return;
    }

    setIsProcessing(true);
    setUploadFeedback('');
    setParsedResult(null);

    // Convert tab/comma separated string into nested string[][] array for structured processing
    const rows = pasteContent.split('\n').map(row => {
      if (row.includes('\t')) return row.split('\t');
      return row.split(',');
    }).filter(row => row.length > 0 && row.some(cell => cell.trim().length > 0));

    try {
      const res = await fetch('/api/ai/parse-excel', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ data: rows })
      });

      const json = await res.json();
      if (json.success && json.parsed) {
        setParsedResult(json.parsed);
        setUploadFeedback('Đã phân tích cấu trúc bảng thành công! Xem trước danh sách nhiệm vụ AI đề xuất phía dưới.');
      } else {
        setUploadFeedback('Lỗi phân tích từ AI. Máy chủ không phản hồi đúng định dạng.');
      }
    } catch (error) {
      setUploadFeedback('Một sự cố mạng xảy ra khi truyền tải dữ liệu về Tín Dân AI.');
    } finally {
      setIsProcessing(false);
    }
  };

  const commitImportedTasksToDb = async () => {
    if (!parsedResult || parsedResult.tasks.length === 0) return;

    const existingTasks = await DB.getTasks(currentUser);

    const newTasks: Task[] = parsedResult.tasks.map((parsed, i) => {
      // Clean and normalize room data
      let dept: Department = Department.MARKETING;
      const parsedDeptLC = String(parsed.department).toLowerCase();
      if (parsedDeptLC.includes('sale') || parsedDeptLC.includes('bán hàng')) dept = Department.SALE;
      else if (parsedDeptLC.includes('kỹ thuật') || parsedDeptLC.includes('tech') || parsedDeptLC.includes('in')) dept = Department.KY_THUAT;
      else if (parsedDeptLC.includes('kho') || parsedDeptLC.includes('logistics')) dept = Department.KHO;
      else if (parsedDeptLC.includes('cskh') || parsedDeptLC.includes('chăm sóc')) dept = Department.CSKH;
      else if (parsedDeptLC.includes('kế toán') || parsedDeptLC.includes('thu chi')) dept = Department.KE_TOAN;
      else if (parsedDeptLC.includes('admin') || parsedDeptLC.includes('sếp')) dept = Department.ADMIN;

      // Clean priority
      let pri: TaskPriority = TaskPriority.MEDIUM;
      if (String(parsed.priority).toLowerCase().includes('high') || String(parsed.priority).toLowerCase().includes('cao')) pri = TaskPriority.HIGH;
      if (String(parsed.priority).toLowerCase().includes('low') || String(parsed.priority).toLowerCase().includes('thấp')) pri = TaskPriority.LOW;

      const checklistItems = Array.isArray(parsed.checklist) 
        ? parsed.checklist.map((c: string, idx: number) => ({ id: `imported_cl_${Date.now()}_${i}_${idx}`, title: c, done: false }))
        : [{ id: `imported_cl_${Date.now()}_${i}_default`, title: 'Thu thập tài liệu ban đầu', done: false }];

      return {
        id: `imported_task_${Date.now()}_${i}`,
        projectId: 'p1',
        projectName: parsed.projectName || 'Dự án in mẫu lẻ',
        title: parsed.title || 'Công việc từ Excel',
        description: parsed.description || 'Chưa cập nhật nội dung chi tiết',
        checklist: checklistItems,
        deadline: parsed.deadline || '2026-06-15',
        assignee: parsed.assignee || 'Nguyễn Văn Nam',
        department: dept,
        priority: pri,
        status: TaskStatus.PENDING,
        attachments: [],
        commentsCount: 0,
        kpiScore: parsed.kpiScore || 12,
        planMonth: parsed.planMonth || 'Tháng 6',
        planWeek: parsed.planWeek || 'Tuần 1',
        overdueRisk: false
      };
    });

    const union = [...newTasks, ...existingTasks];
    DB.saveTasks(newTasks);
    onImportComplete(newTasks);

    setParsedResult(null);
    setPasteContent('');
    setUploadFeedback('Chúc mừng! Đã nhập thành công tất cả đầu việc vào bảng Kanban Tín Dân.');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Module Title */}
      <div>
        <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display">
          AI Auto Import Excel / CSV Plan
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Dán trực tiếp bảng sao chép từ Microsoft Excel / Google Sheets kế hoạch của bạn. AI sẽ phân tách các cột Vietnamese linh hoạt để nhập tự động.
        </p>
      </div>

      {/* Alert / Prompt boxes */}
      {uploadFeedback && (
        <div className={`p-3.5 text-xs rounded-xl flex items-start gap-2.5 border ${
          uploadFeedback.includes('Chúc mừng') || uploadFeedback.includes('thành công')
            ? 'bg-emerald-50 text-emerald-600 border-emerald-200 dark:bg-emerald-950/20' 
            : 'bg-blue-50 text-blue-650 border-blue-200 dark:bg-slate-800'
        }`}>
          <AlertCircle className="w-4.5 h-4.5 shrink-0" />
          <span>{uploadFeedback}</span>
        </div>
      )}

      {/* Layout Grid details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side (Uploader Canvas & Pasteboard) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold font-display text-slate-800 dark:text-white uppercase tracking-wider">Khu vực dán bảng Kế Hoạch</span>
              <button
                type="button"
                onClick={copyTemplate}
                className="text-xs text-blue-600 font-semibold hover:underline flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy bảng mẫu Excel test</span>
              </button>
            </div>

            {/* Drag Drop dropzone */}
            <div
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              className="border-2 border-dashed border-white/10 hover:border-blue-500 rounded-xl p-6 text-center space-y-2 cursor-pointer relative bg-white/5 dark:bg-black/10 duration-200"
            >
              <Upload className="w-8 h-8 text-slate-400 mx-auto" />
              <div className="text-xs text-slate-600 dark:text-slate-300">
                <span className="font-bold text-blue-600">Thả file Excel/CSV kế hoạch</span> hoặc click tải lên
              </div>
              <p className="text-[10px] text-slate-400 font-light">Chấp nhận định dạng .csv, mẫu dòng dữ liệu phân chia rõ rệt.</p>
              
              <input
                type="file"
                accept=".csv,.txt"
                onChange={handleFileChange}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </div>

            {/* Paste large textbox */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-500">Hoặc dán tay dữ liệu cột ô (Ctrl + V):</label>
              <textarea
                value={pasteContent}
                onChange={(e) => setPasteContent(e.target.value)}
                rows={7}
                placeholder="Dự án	Tên Công Việc	Người gánh vác	Phòng	Ưu tiên	Hạn chót...&#10;Marketing VF5	Lên poster truyền thông	Nguyễn Văn Nam	Marketing	High	2026-06-15"
                className="w-full glass-input text-xs py-2.5 px-3.5 focus:outline-none focus:ring-1 focus:ring-blue-550 rounded-xl font-mono text-slate-800 dark:text-slate-200"
              />
            </div>

            {/* Trigger parse API button */}
            <button
              type="button"
              onClick={executeAiAnalysis}
              disabled={isProcessing}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer disabled:bg-slate-300"
            >
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span>{isProcessing ? 'Đang chạy bộ phân tích Gemini 3.5...' : 'Dùng AI Phân Tích & Map Cột Tự Động'}</span>
            </button>

          </div>
        </div>

        {/* Right Side (Visual mapped preview output) */}
        <div className="lg:col-span-6">
          <div className="glass-card rounded-2xl p-5 min-h-[460px] flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center border-b border-white/5 pb-3 mb-4">
                <span className="text-xs font-bold font-display text-slate-800 dark:text-white uppercase tracking-wider">Xem trước phân tích AI</span>
                {parsedResult && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-500">
                    <span>Độ tin cậy:</span>
                    <span className="font-bold py-0.5 px-2 rounded-full bg-blue-50 text-blue-600 font-mono">
                      {Math.round(parsedResult.confidenceScore * 100)}%
                    </span>
                  </div>
                )}
              </div>

              {!parsedResult ? (
                <div className="py-24 text-center text-slate-350 dark:text-slate-500 space-y-3">
                  <Grid3X3 className="w-12 h-12 mx-auto text-slate-200 dark:text-slate-750" />
                  <p className="text-xs italic leading-relaxed max-w-xs mx-auto">Chưa có kết quả. Dán dữ liệu cột ô ở bảng trái và bấm phân tích để xem mẫu ánh xạ trước khi lưu chính thức.</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-[340px] overflow-y-auto pr-1">
                  <div className="text-xs font-semibold text-blue-600 dark:text-blue-400 bg-blue-50/30 p-2 rounded-lg">
                    🧠 Hệ thống phát hiện {parsedResult.tasks.length} cấu trúc công việc phù hợp!
                  </div>

                  <div className="space-y-3">
                    {parsedResult.tasks.map((t, idx) => (
                      <div key={idx} className="p-3 bg-white/5 dark:bg-black/20 border border-white/5 rounded-xl space-y-1.5">
                        <div className="flex justify-between items-start">
                          <span className="text-xs font-bold font-display text-slate-800 dark:text-white">{t.title}</span>
                          <span className="text-[10px] font-bold text-emerald-600">+{t.kpiScore}đ KPI</span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">{t.description}</p>
                        
                        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100 dark:border-slate-700/80 text-[10px] text-slate-500">
                          <span className="bg-blue-100/50 text-blue-700 dark:bg-blue-900/10 px-1.5 py-0.5 rounded">
                            {t.department}
                          </span>
                          <span>Đảm nhiệm: <b>{t.assignee}</b></span>
                          <span>Hạn: <b>{t.deadline}</b></span>
                        </div>

                        {t.checklist && t.checklist.length > 0 && (
                          <div className="pt-1 space-y-0.5">
                            <span className="text-[9px] font-semibold text-slate-400">Checklist phụ AI tự gom:</span>
                            <div className="grid grid-cols-2 gap-1 text-[10px] font-light">
                              {t.checklist.slice(0, 4).map((c: string, cidx: number) => (
                                <div key={cidx} className="flex items-center gap-1 text-slate-650">
                                  <span className="w-1 h-1 rounded-full bg-slate-400" />
                                  <span className="truncate">{c}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Commit to main store state trigger */}
            {parsedResult && parsedResult.tasks.length > 0 && (
              <div className="pt-4 border-t border-slate-150 dark:border-slate-800 flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setParsedResult(null)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold rounded-lg"
                >
                  Xóa kết quả
                </button>
                <button
                  type="button"
                  onClick={commitImportedTasksToDb}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 font-bold text-white rounded-lg flex items-center gap-1.5 shadow-md shadow-blue-600/10"
                >
                  <Database className="w-4 h-4" />
                  <span>Chấp Thuận & Lưu Vào Hệ Thống</span>
                </button>
              </div>
            )}

          </div>
        </div>

      </div>

    </div>
  );
}
