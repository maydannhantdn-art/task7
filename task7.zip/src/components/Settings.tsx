/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, ThemeMode } from '../types';
import { DB } from '../lib/dataStore';
import { Settings as SettingsIcon, Sliders, HardDrive, Palette, Sparkles, CheckCircle2, ShieldAlert, Activity, Wifi, Copy, Check, RefreshCw } from 'lucide-react';

interface SettingsProps {
  currentUser: User;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  onAddNotification: (title: string, content: string, type: string) => void;
  onUpdateUser: (user: User) => void;
}

export default function Settings({ currentUser, themeMode, setThemeMode, onAddNotification, onUpdateUser }: SettingsProps) {
  const [targetKPI, setTargetKPI] = useState<number>(100);
  const [modelName, setModelName] = useState('gemini-3.5-flash');
  const [adminBypass, setAdminBypass] = useState(true);
  const [showConfigAlert, setShowConfigAlert] = useState('');

  const [selectedAvatar, setSelectedAvatar] = useState(currentUser.avatar || '');
  const [customUrlInput, setCustomUrlInput] = useState(currentUser.avatar || '');

  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionResult, setConnectionResult] = useState<{ success: boolean; message: string; latencyMs?: number } | null>(null);
  const [copied, setCopied] = useState(false);
  const [showSql, setShowSql] = useState(false);

  // Admin Change Password States
  const [currentPasswordInput, setCurrentPasswordInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [passFeedback, setPassFeedback] = useState<{ success: boolean; message: string } | null>(null);

  const avatarStyles = [
    'avataaars',
    'bottts',
    'pixel-art',
    'miniavs',
    'adventurer',
    'big-smile'
  ];

  const handleAvatarChange = async (style: string) => {
    const newAvatar = `https://api.dicebear.com/7.x/${style}/svg?seed=${currentUser.name}_${Math.random()}`;
    setSelectedAvatar(newAvatar);
    
    const updatedUser = { ...currentUser, avatar: newAvatar };
    onUpdateUser(updatedUser);
    await DB.updateUser(currentUser.id, { avatar: newAvatar });
    
    setShowConfigAlert('Đã cập nhật ảnh đại diện mới!');
    setTimeout(() => setShowConfigAlert(''), 3000);
  };

  const saveConfigurations = (e: React.FormEvent) => {
    e.preventDefault();
    setShowConfigAlert('Đã cập nhật cấu hình tham số xưởng in Tem Vivian vào lõi Tín Dân CRM!');
    
    // Add positive tracking
    onAddNotification(
      'Cập nhật cấu hình hệ thống',
      `Sếp ${currentUser.name} vừa cập nhật KPI kế hoạch là ${targetKPI}đ và cấu hình AI model: ${modelName}.`,
      'settings'
    );

    setTimeout(() => {
      setShowConfigAlert('');
    }, 4000);
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassFeedback(null);

    if (!currentPasswordInput || !newPasswordInput || !confirmPasswordInput) {
      setPassFeedback({ success: false, message: 'Vui lòng điền đầy đủ các trường thông tin.' });
      return;
    }

    const actualCurrentPassword = currentUser.password || (currentUser.name === 'Admin' ? '123456' : '123');
    if (currentPasswordInput !== actualCurrentPassword) {
      setPassFeedback({ success: false, message: 'Mật khẩu hiện tại không chính xác sếp ơi.' });
      return;
    }

    if (newPasswordInput.length < 4) {
      setPassFeedback({ success: false, message: 'Mật khẩu mới phải từ 4 ký tự trở lên để bảo mật.' });
      return;
    }

    if (newPasswordInput !== confirmPasswordInput) {
      setPassFeedback({ success: false, message: 'Xác nhận mật khẩu mới không trùng khớp.' });
      return;
    }

    try {
      const updatedUser = { ...currentUser, password: newPasswordInput };
      
      onUpdateUser(updatedUser);
      await DB.updateUser(currentUser.id, { password: newPasswordInput });
      
      localStorage.setItem('tindan_current_user', JSON.stringify(updatedUser));
      
      setPassFeedback({ success: true, message: 'Đổi mật khẩu tài khoản thành công!' });
      
      setCurrentPasswordInput('');
      setNewPasswordInput('');
      setConfirmPasswordInput('');
      
      onAddNotification(
        'Bảo mật',
        `Tài khoản ${currentUser.name} đã cập nhật mật khẩu đăng nhập hệ thống thành công.`,
        'settings'
      );
    } catch (err: any) {
      setPassFeedback({ success: false, message: `Lỗi khi lưu mật khẩu mới: ${err.message || err}` });
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Title */}
      <div>
        <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display">Cấu Hình Quản Trị Hệ Thống</h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Vùng hiệu chỉnh tham số, mô hình AI điều phối, và thông số KPI tháng của Tín Dân CRM.</p>
      </div>

      {showConfigAlert && (
        <div className="p-3.5 bg-emerald-50 text-emerald-600 border border-emerald-250 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          <span>{showConfigAlert}</span>
        </div>
      )}

      {/* Settings Panel Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* Left column - main settings forms */}
        <div className="md:col-span-8">
          <div className="glass-card rounded-2xl p-6 space-y-6">
            
            {/* Visual themes section */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Palette className="w-4 h-4 text-blue-500" />
                <span>Môi trường và Giao diện</span>
              </h3>

              <div className="grid grid-cols-3 gap-3">
                {Object.values(ThemeMode).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setThemeMode(mode)}
                    className={`py-2 px-3 border rounded-xl text-xs font-semibold text-center transition-all ${
                      themeMode === mode 
                        ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-600/10' 
                        : 'bg-slate-150 text-slate-600 border-slate-200/60 font-medium'
                    }`}
                  >
                    {mode === ThemeMode.LIGHT ? 'Sáng (Light)' : mode === ThemeMode.DARK ? 'Sẫm (Dark)' : 'Kết nối máy'}
                  </button>
                ))}
              </div>
            </div>

            {/* Target parameters */}
            <div className="space-y-3 border-t border-slate-100 dark:border-slate-800 pt-5">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-500" />
                <span>Thông số KPI quy chuẩn tháng</span>
              </h3>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Mục tiêu KPI cá nhân</label>
                  <input
                    type="number"
                    value={targetKPI}
                    onChange={(e) => setTargetKPI(parseInt(e.target.value) || 100)}
                    className="w-full glass-input rounded-lg py-2 px-3 text-xs text-slate-800 dark:text-slate-200 font-bold font-mono"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">Mẫu kpi lý tưởng hoàn thành.</span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Mô hình chỉ định AI LLM</label>
                  <select
                    value={modelName}
                    onChange={(e) => setModelName(e.target.value)}
                    className="w-full glass-dropdown rounded-lg py-2 px-3 text-xs text-slate-800 dark:text-slate-200 font-bold focus:outline-none"
                  >
                    <option value="gemini-3.5-flash">Gemini 3.5 Flash (Tốc độ cao)</option>
                    <option value="gemini-2.5-pro">Gemini 2.5 Pro (Suy luận sâu)</option>
                    <option value="deepseek-v3">DeepSeek Cổ Điển</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Administrator switches */}
            <div className="space-y-3 border-t border-slate-100 dark:border-slate-800 pt-5 text-xs text-slate-700">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={adminBypass}
                  onChange={(e) => setAdminBypass(e.target.checked)}
                  className="w-4 h-4 accent-blue-600 rounded"
                />
                <span className="font-semibold">Kích hoạt chế độ gộp dữ liệu KPI liên phòng ban</span>
              </label>
              <p className="text-[10px] text-slate-400 pl-6">Cho phép quản lý trực thuộc xem chéo tiến độ sấy UV decal và doanh thu Sale để tối ưu phân công liên phòng ban.</p>
            </div>

            {/* Cache maintenance utility */}
            <div className="space-y-3 border-t border-slate-100 dark:border-slate-800 pt-5 text-xs">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-red-500" />
                <span>Bảo Trì và Dọn Dẹp Cache Hệ Thống</span>
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-sans font-medium">
                Sếp có thể dọn sạch toàn bộ bộ nhớ cache cục bộ (localStorage) của Tín Dân CRM để thiết lập và tải lại các thông số sạch hoàn toàn từ Firebase mới nhất.
              </p>
              <button
                type="button"
                onClick={() => {
                  DB.clearSystemCache();
                  setShowConfigAlert('Đang tự động xóa sạch cache và đặt lại cấu trúc dữ liệu...');
                  setTimeout(() => {
                    window.location.reload();
                  }, 1200);
                }}
                className="py-1.5 px-4 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-950/40 text-red-600 border border-red-200 dark:border-red-900 rounded-xl font-bold flex items-center gap-1.5 transition-all text-xs cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5 text-red-500 animate-spin" style={{ animationDuration: '4s' }} />
                <span>Tự Động Làm Sạch Hệ Thống & Reload Trang</span>
              </button>
            </div>

            {/* Account Password Change (Requested by user) */}
            <form onSubmit={handlePasswordChange} className="space-y-4 border-t border-slate-100 dark:border-slate-800 pt-5 text-xs">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                <SettingsIcon className="w-4 h-4 text-emerald-500" />
                <span>Bảo Mật & Thay Đổi Mật Khẩu</span>
              </h3>
              
              {passFeedback && (
                <div className={`p-3 rounded-lg border text-xs font-sans ${
                  passFeedback.success 
                    ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900 text-emerald-600 dark:text-emerald-400' 
                    : 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900 text-red-600 dark:text-red-400'
                }`}>
                  {passFeedback.message}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Mật khẩu hiện tại</label>
                  <input
                    type="password"
                    required
                    value={currentPasswordInput}
                    onChange={(e) => setCurrentPasswordInput(e.target.value)}
                    placeholder="Mật khẩu đang dùng"
                    className="w-full bg-[#121625] border border-slate-800/80 rounded-xl px-3.5 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Mật khẩu mới</label>
                  <input
                    type="password"
                    required
                    value={newPasswordInput}
                    onChange={(e) => setNewPasswordInput(e.target.value)}
                    placeholder="Tối thiểu 4 ký tự"
                    className="w-full bg-[#121625] border border-slate-800/80 rounded-xl px-3.5 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1.5">Xác nhận mật khẩu</label>
                  <input
                    type="password"
                    required
                    value={confirmPasswordInput}
                    onChange={(e) => setConfirmPasswordInput(e.target.value)}
                    placeholder="Gõ lại mật khẩu mới"
                    className="w-full bg-[#121625] border border-[#ef4444]/10 rounded-xl px-3.5 py-1.5 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  className="py-1.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition-all shadow-md shadow-emerald-500/15 cursor-pointer block"
                >
                  Cập mật khẩu mới
                </button>
              </div>
            </form>

            {/* Form submit */}
            <div className="pt-4 border-t border-white/5 flex justify-end text-xs">
              <button
                type="button"
                onClick={saveConfigurations}
                className="py-2.5 px-6 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md cursor-pointer"
              >
                Lưu Thay Đổi Cấu Hình
              </button>
            </div>

          </div>
        </div>

        {/* Right column - profile dashboard info card */}
        <div className="md:col-span-4 space-y-4">
          <div className="glass-card rounded-2xl p-5 text-xs space-y-4">
            
            <div className="flex items-center gap-2 font-bold font-display uppercase tracking-wider text-slate-800 dark:text-white">
              <SettingsIcon className="w-4 h-4 text-slate-500" />
              <span>Cá nhân sở tại</span>
            </div>

            <div className="flex flex-col items-center gap-3 py-2">
              <img 
                src={selectedAvatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.name}`} 
                alt="Avatar" 
                className="w-20 h-20 rounded-2xl border-2 border-blue-500/20 shadow-lg object-cover"
              />
              <span className="text-[10px] text-slate-400 font-medium text-center block w-full">Chọn nhanh qua 6 phong cách ảnh đại diện:</span>
              <div className="grid grid-cols-3 gap-1.5 w-full">
                {avatarStyles.map(style => (
                  <button
                    key={style}
                    onClick={() => handleAvatarChange(style)}
                    className="p-1 border border-slate-200 dark:border-slate-800 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all text-[9.5px] font-bold capitalize truncate cursor-pointer"
                  >
                    {style.replace('-', ' ')}
                  </button>
                ))}
              </div>

              <div className="w-full pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-medium block">Hoặc tự điền địa chỉ URL ảnh của bạn:</span>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    value={customUrlInput}
                    onChange={(e) => setCustomUrlInput(e.target.value)}
                    placeholder="Dán link liên kết ảnh (.png/jpg...)"
                    className="flex-grow p-1.5 border border-slate-250 dark:border-white/5 rounded-lg text-[9.5px] font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <button
                    onClick={async () => {
                      if (!customUrlInput) return;
                      setSelectedAvatar(customUrlInput);
                      const updatedUser = { ...currentUser, avatar: customUrlInput };
                      onUpdateUser(updatedUser);
                      await DB.updateUser(currentUser.id, { avatar: customUrlInput });
                      setShowConfigAlert('Đã cập nhật lưu ảnh đại diện tự chọn sếp nhé!');
                      setTimeout(() => setShowConfigAlert(''), 3000);
                    }}
                    className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-[10px] cursor-pointer shrink-0"
                  >
                    Lưu
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 block">Tên nhân viên:</span>
              <span className="font-bold text-slate-900 dark:text-white block">{currentUser.name}</span>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 block">Phòng ban làm việc:</span>
              <span className="font-bold text-blue-600 block">Phòng {currentUser.department}</span>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400 block">Cấp bậc hệ thống:</span>
              <span className="font-bold text-slate-900 dark:text-white block">{currentUser.role}</span>
            </div>

            <div className="p-3 bg-blue-50/10 border border-blue-200/25 rounded-xl space-y-1 leading-relaxed text-[10px] text-blue-600 dark:text-blue-400">
              <div className="flex items-center gap-1.5 font-bold uppercase">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Quyền hạn tối đa</span>
              </div>
              <p>Tài khoản của bạn có đủ thẩm quyền phê duyệt kế hoạch, thưởng thêm điểm KPI, nạp kế hoạch in tự động và cấu hình AI.</p>
            </div>

          </div>
        </div>

      </div>

      {/* Dynamic Firebase Firestore Connection Status Verification for Sếp */}
      <div className="glass-card rounded-2xl overflow-hidden mt-6 border border-blue-500/20 shadow-lg">
        <div className="p-4 bg-gradient-to-r from-slate-900 via-slate-800 to-blue-900 text-white flex justify-between items-center flex-wrap gap-2 animate-fade-in">
          <div className="flex items-center gap-2">
            <Wifi className="w-5 h-5 text-emerald-400 animate-pulse" />
            <div>
              <span className="font-bold text-xs uppercase tracking-wider block">XÁC MINH CƠ SỞ DỮ LIỆU FIREBASE (CẬP NHẬT THEO LỆNH SẾP)</span>
              <span className="text-[10px] text-slate-300">Đồng bộ tự chuyển dời sang cơ sở dữ liệu đám mây Firebase Firestore tối tân, schema-less 100% không lo lỗi cột!</span>
            </div>
          </div>
          <span className="text-[10px] bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded font-mono font-bold uppercase">FIREBASE LIVE</span>
        </div>

        <div className="p-5 space-y-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-5 text-xs font-sans">
            <div className="space-y-1.5 max-w-xl">
              <h4 className="font-bold text-slate-800 dark:text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-500" />
                <span>Chẩn đoán tích hợp Firebase Firestore Cloud</span>
              </h4>
              <p className="text-[11.5px] text-slate-500 dark:text-slate-400 leading-relaxed font-sans font-medium">
                Thực hiện kiểm tra ghi và đọc dữ liệu (Write → Read → Delete) trực tiếp trên cơ sở dữ liệu Firestore của Sếp (<code>ai-studio-eda75b50-ba52-4433-9f30-47c7a51ce363</code>). Firebase Firestore lưu trữ linh hoạt mọi thuộc tính (checklist, followers, kpiScore) tức thì mà không cần khai báo schema cột phức tạp!
              </p>
              {connectionResult && (
                <div className={`p-3.5 rounded-xl border ${
                  connectionResult.success 
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400' 
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-600 dark:text-rose-450'
                } font-mono text-[11px] mt-2`}>
                  <span className="font-bold uppercase block mb-1">
                    [{connectionResult.success ? '✓ KẾT NỐI HOÀN HẢO' : '✗ THẤT BẠI'}]
                  </span>
                  <p className="font-sans m-0">{connectionResult.message}</p>
                  {connectionResult.latencyMs && (
                    <p className="mt-1 text-[10px] opacity-80">
                      Thời gian phản hồi máy chủ Firebase: <b>{connectionResult.latencyMs} ms</b> (Cực kỳ nhạy bén, đồng bộ live tức thời)
                    </p>
                  )}
                </div>
              )}
            </div>

            <button
              type="button"
              disabled={testingConnection}
              onClick={async () => {
                setTestingConnection(true);
                setConnectionResult(null);
                try {
                  const res = await DB.testFirestoreConnection();
                  setConnectionResult(res);
                  if (res.success) {
                    onAddNotification(
                      'Tích hợp Firebase',
                      `Đã liên kết kết nối Firebase Firestore thành công rực rỡ với máy chủ của Tín Dân. Phản hồi: ${res.latencyMs}ms.`,
                      'settings'
                    );
                  }
                } catch (e: any) {
                  setConnectionResult({
                    success: false,
                    message: `Lỗi bất ngờ khi gửi gói tin lên Firebase: ${e.message || e}`
                  });
                } finally {
                  setTestingConnection(false);
                }
              }}
              className={`w-full md:w-auto py-2.5 px-6 font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-all border-none uppercase cursor-pointer shrink-0 ${
                testingConnection 
                  ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/15'
              }`}
            >
              {testingConnection ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent animate-spin rounded-full" />
                  <span>Đang kiểm tra...</span>
                </>
              ) : (
                <>
                  <Wifi className="w-4 h-4" />
                  <span>Kiểm tra kết nối Firebase</span>
                </>
              )}
            </button>
          </div>

          <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-2">
            <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 text-xs font-bold uppercase">
              <HardDrive className="w-4 h-4 text-emerald-500" />
              <span>Ưu Điểm Độc Tôn Của Đám Mây Firebase Tín Dân Mới</span>
            </span>
            <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
              ✔️ <b>Websocket Active Live:</b> Bất kỳ sự thay đổi công việc nào từ phía Nhân viên sẽ lập tức đẩy trực tiếp lên màn hình của Sếp trong vòng 0.5s theo mô hình Socket lắng nghe, loại bỏ hoàn toàn việc phải nhấn "Đồng bộ thủ công".
              <br />
              ✔️ <b>Vận Hành Không Lỗi Cột:</b> Đám mây NoSQL Firestore lưu trữ các danh sách con linh hoạt, bảo toàn toàn bộ dữ liệu tạo bởi nhân viên ngay cả khi có bất đồng bộ kết nối tạm thời.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
}
