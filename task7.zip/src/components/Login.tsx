/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, UserRole, Department } from '../types';
import { DB } from '../lib/dataStore';
import { ensureAuth } from '../lib/firebase';
import { KeyRound, ShieldAlert, CheckCircle2, RefreshCw, LayoutDashboard, Sparkles } from 'lucide-react';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [selectedDept, setSelectedDept] = useState<Department>(Department.ADMIN);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [showForgot, setShowForgot] = useState(false);
  const [isDataLoading, setIsDataLoading] = useState(true);

  // Load users once on mount - robust cache-first and background sync
  React.useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsDataLoading(true);
        // 1. Instantly read from the local cache so the CRM loads in milliseconds
        const cached = DB.getCachedUsers();
        if (cached && cached.length > 0) {
          setUsers(cached);
          setIsDataLoading(false); // Enable interactive login instantly
        }
        
        // 2. Safely attempt background Firestore update
        await ensureAuth();
        const data = await DB.getUsers();
        if (data && data.length > 0) {
          setUsers(data);
        }
      } catch (err) {
        console.warn("Relying entirely on robust local storage cache due to Firestore connection limits:", err);
      } finally {
        setIsDataLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const depts = Object.values(Department);

  const handleCleanCache = () => {
    DB.clearSystemCache();
    setSuccessMsg('Hệ thống đã tự động dọn sạch Cache trình duyệt thành công! Trình quản trị đang tải lại cấu trúc sạch mới...');
    setTimeout(() => {
      window.location.reload();
    }, 1200);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    // Find matching user
    let foundUser = users.find(u => 
      u.email.trim().toLowerCase() === email.trim().toLowerCase() ||
      u.name.trim().toLowerCase() === email.trim().toLowerCase()
    );
    
    if (!foundUser && (email.trim().toLowerCase() === 'admin' || email.trim().toLowerCase() === 'admin@tindan.com') && password === '123456') {
      foundUser = {
        id: '1',
        name: 'Admin',
        email: 'admin@tindan.com',
        role: 'CEO / Quản lý tối cao',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
        password: '123456',
        permissions: ['workspace', 'inbox', 'tasks', 'projects', 'teams', 'crm', 'ai-command', 'knowledge', 'kpis', 'automation', 'notifications', 'files', 'settings']
      };
    }
    
    if (foundUser) {
      if (foundUser.status === 'locked') {
        setErrorMessage('Tài khoản này đã bị khóa bởi Admin. Vui lòng liên hệ hỗ trợ.');
        return;
      }

      // Verify password if user has one (simulation)
      const expectedPassword = foundUser.password || (foundUser.name === 'Admin' ? '123456' : '123');
      if (expectedPassword && expectedPassword !== password) {
        setErrorMessage('Mật khẩu không chính xác. Vui lòng kiểm tra lại.');
        return;
      }
      
      // Successfully authenticated
      DB.setCurrentUser(foundUser);
      setSuccessMsg(`Đăng nhập thành công! Bộ phận: ${selectedDept}`);
      setTimeout(() => {
        onLoginSuccess({
          ...foundUser,
          department: selectedDept // Set requested department workspace
        });
      }, 800);
    } else {
      setErrorMessage('Không tìm thấy tài khoản với tên đăng nhập hoặc email này trong hệ thống.');
    }
  };

  const handleQuickLogin = (user: User) => {
    setErrorMessage('');
    setEmail(user.email);
    setPassword(user.password || '••••••••');
    setSelectedDept(user.department);
    
    DB.setCurrentUser(user);
    setSuccessMsg(`Đăng nhập siêu tốc: ${user.name}`);
    setTimeout(() => {
      onLoginSuccess(user);
    }, 800);
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) {
      setErrorMessage('Vui lòng nhập Email cần lấy lại mật khẩu');
      return;
    }
    setSuccessMsg(`Yêu cầu đặt lại mật khẩu đã gửi tới ${forgotEmail}!`);
    setShowForgot(false);
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 dark:bg-slate-950 font-sans transition-colors duration-300">
      
      {/* Decorative branding sidebar - Left Side */}
      <div className="w-full md:w-[45%] bg-gradient-to-br from-blue-700 via-blue-600 to-indigo-800 text-white flex flex-col justify-between p-8 md:p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(255,255,255,0.15),transparent)] pointer-events-none" />
        <div className="absolute -bottom-24 -left-20 w-80 h-80 bg-blue-500/20 rounded-full blur-2xl glow-animation" />
        
        {/* Top Header Logo Banner */}
        <div className="flex items-center gap-3 relative z-10">
          <div className="bg-white p-1.5 rounded-xl shadow-lg flex items-center justify-center">
            <img 
              src="https://temvivian.vn/wp-content/uploads/2024/11/logo-tin-dan-tdn.png" 
              alt="Logo Tín Dân" 
              className="h-10 w-auto object-contain"
              onError={(e) => {
                // Return a beautiful fallback if broken image
                e.currentTarget.src = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=80&auto=format&fit=crop&q=60";
              }}
            />
          </div>
          <div>
            <span className="font-display font-bold tracking-tight text-xl block">TÍN DÂN CRM</span>
            <span className="text-xs text-blue-200 block tracking-wider font-mono">WORKSPACE OS v1.0</span>
          </div>
        </div>

        {/* Hero Slogan */}
        <div className="my-12 md:my-0 select-none relative z-10">
          <div className="inline-flex items-center gap-1.5 bg-blue-500/20 text-blue-200 text-xs px-2.5 py-1 rounded-full mb-4">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>Hệ thống tích hợp Trí tuệ nhân tạo (AI)</span>
          </div>
          <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold leading-tight mb-4 tracking-tight">
            Quản trị Vận hành <br />
            & Tối ưu Doanh thu
          </h1>
          <p className="text-blue-100/90 text-sm md:text-base leading-relaxed max-w-sm font-light">
            Nhận diện lỗi sản xuất xưởng in Tem Vivian, tự động hóa phân công công việc & theo sát năng lượng KPI từng vị trí bằng bộ công cụ AI tối tân.
          </p>
        </div>

        {/* Footer info */}
        <div className="text-xs text-blue-200 border-t border-blue-500/30 pt-6 relative z-10 font-mono">
          © 2026 Tín Dân Company. All rights reserved.
        </div>
      </div>

      {/* Main Login Form - Right Side */}
      <div className="flex-1 flex items-center justify-center p-6 md:p-12 relative">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xl rounded-2xl p-6 md:p-8 relative">
          
          <div className="mb-6 text-center md:text-left">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-white font-display">Đăng nhập tài khoản</h2>
            <p className="text-sm text-slate-500 dark:text-gray-400 mt-1">Chọn phân vùng phòng ban để tải không gian làm việc</p>
          </div>

          {/* Feedback alerts */}
          {errorMessage && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 text-xs text-red-600 dark:text-red-400 rounded-lg flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}
          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-600 dark:text-emerald-400 rounded-lg flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-500" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Department Selection Slots */}
          <div className="mb-5">
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2 uppercase tracking-wide">
              Môi trường Phòng ban
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5">
              {depts.map((dept) => (
                <button
                  key={dept}
                  type="button"
                  onClick={() => setSelectedDept(dept)}
                  className={`py-1.5 px-2 text-xs rounded-lg border text-center font-medium font-display transition-all ${
                    selectedDept === dept
                      ? 'bg-blue-600 text-white border-blue-600 font-semibold shadow-md shadow-blue-500/10'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {dept}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">
                Tài khoản / Email
              </label>
              <input
                type="text"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="vd: tuananhcdv hoặc email..."
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="relative">
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Mật khẩu
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgot(!showForgot)}
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                >
                  Quên mật khẩu?
                </button>
              </div>

              <input
                type="password"
                required={!showForgot}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Nhập mật khẩu"
                className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Forgot password nested pane */}
            {showForgot && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg space-y-2">
                <p className="text-xs text-slate-500 dark:text-slate-400">Nhập email phục hồi mật khẩu hệ thống</p>
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="email@tindan.vn"
                    className="flex-1 px-2.5 py-1 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded"
                  />
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    className="bg-blue-600 text-white px-3 py-1 text-xs font-medium rounded hover:bg-blue-700"
                  >
                    Gửi
                  </button>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-3.5 h-3.5 accent-blue-600 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                Ghi nhớ đăng nhập
              </label>

              {/* Robust Cache Cleaning Trigger (Requested by Sếp) */}
              <button
                type="button"
                onClick={handleCleanCache}
                className="text-xs text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400 font-semibold transition-all flex items-center gap-1 cursor-pointer bg-slate-50 hover:bg-red-50 dark:bg-slate-800 dark:hover:bg-red-950/20 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 hover:border-red-200 dark:hover:border-red-900"
                title="Dọn dẹp & Tải mới lại toàn bộ hệ thống"
              >
                <RefreshCw className="w-3 h-3 text-red-500 animate-spin" style={{ animationDuration: '3s' }} />
                <span>Làm sạch Cache</span>
              </button>
            </div>

            <button
              type="submit"
              disabled={isDataLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-medium py-2 px-4 rounded-lg flex items-center justify-center gap-2 text-sm transition-all shadow-md shadow-blue-600/15"
            >
              {isDataLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <KeyRound className="w-4 h-4" />
              )}
              <span>{isDataLoading ? 'Đang tải dữ liệu...' : 'Vào không gian làm việc'}</span>
            </button>
          </form>

        </div>
      </div>
    </div>
  );
}
